import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
// import { Console } from 'node:console';
import { Product } from 'src/app/products/product';
import { ProductService } from 'src/app/products/product.service';
import { Cart } from '../cart';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-add-tem',
  templateUrl: './add-tem.component.html',
  styleUrls: ['./add-tem.component.css']
})
export class AddTemComponent implements OnInit {
  productID = 0;
  productData: Product;
  cartData: Cart;

  constructor(private cartService: CartService, private activatedRoute: ActivatedRoute, private productService: ProductService) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe(data => {
      this.productID = data.id;
      console.log("id:", this.productID);
    })



    this.productService.viewProduct(this.productID).subscribe(val => {
      this.productData = val;
      console.log("Add this to Cart:", this.productData);
    })


    //------------------------------------------------------

    setTimeout(() => {
      console.log("Making object: ");
      let obj =
      {
        productId: this.productData.productId,
        quantity: this.productData.quantity,
        status: "in cart only",
        email: "gs@gmail.com"
      };
      console.log("object created:", obj);

      this.cartService.addToCart(obj).subscribe(data => {
        console.log("Subscribed:", data);
      })
    }, 2000);




    //------------------------------------------------------


    // console.log("Making object: ");
    // let obj =
    // {
    //   productId: this.productData.productId,
    //   quantity: this.productData.quantity,
    //   status: "in cart only",
    //   email: "gs@gmail.com"
    // };
    // console.log("object created:", obj);

    // this.cartService.addToCart(obj).subscribe(data => {
    //   console.log("Subscribed:", data);
    // })


  }



}
