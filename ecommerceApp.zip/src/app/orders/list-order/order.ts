export interface Order {
    productId: number,
    email: string,
    quantity: number,
    cost: number,
    cartId: number
}